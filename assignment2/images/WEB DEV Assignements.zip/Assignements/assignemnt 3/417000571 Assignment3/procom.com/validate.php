<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

/* so error messages need revision */
//  intialise error msg
$GLOBALS['err_msg'] = "";
/*

function areCredentialsValid( $user_info)
{
	// todo: this needs a implimentation for throwing false on duplicates 
	if(!is_array($user_info))
	{
		// Chaaa, no array found 😔
		return false;
	}
	// csv stuff

	if(!isset($user_info) || !isset($user_info) ||
		empty($user_info) || empty($user_info))
	{
		return false;
	}

	// get csv for password pair
	$row = 1;
	if (($handle = fopen("procom_users.csv", "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{
			//if(array_key_exists(key, $))
			$num = count($data);
			
			if($user_info[0] == $data[0])
			{
				// found email
				
				if($user_info[1] == $data[6])
				{
					// haha password found 😏 
					fclose($handle);
					return true;	
				}
				// found email but wrong password 😱 
				break;
			}
		}
		// not found/valid
		fclose($handle);
		return false;
	}
}

function isEmailValid($email)
{
	//format bad
	if (!filter_var($email, FILTER_VALIDATE_EMAIL))
	{
		$GLOBALS['err_msg'] .= " Invalid email format";
		$_SESSION['emailerror'] = "Invalid email format";// bad way
		return false; 
	}
	
	return true;
}

function isPasswordValid($password)
{
	// length
	$MIN = 8;
	if (!(strlen($password) >= $MIN))
	{
		$GLOBALS['err_msg'] .= " Password length must at least 8";
		return false;
	}
	//  alphanurmeric
	//if(preg_match('/[^a-z_\-0-9]/i', $password))
	if(!ctype_alnum($password))
	{
		$GLOBALS['err_msg'] .= " Password should contain only alphanumeric characters";
		return false;
	}
	
	//  alphanurmeric
	if(!preg_match('~[0-9]~', $password))
	{
		$GLOBALS['err_msg'] .= " Password must have at least 1 number";
		return false;
	}
	
	return true;
}

// The student id must be: (i) nine integers long and start with 4.
function isIdValid(string $id): bool
{
	//return ((strlen($id) >= 8) && ($id[0] == 4));

	if((strlen($id) >= 8) && ($id[0] == 4))
	{
		return true;
	}

	$_SESSION['stdntiderror'] = "Invalid ID format";
	return false;
}

// The first and last names must be characters only
function isNameValid(string $name): bool
{
	if(ctype_alpha($name))
	{
		return true;
	}
	// handled session in manageStudent
	return false;
}

// The address must be only alphanumeric characters and spaces
function isAddressValid(string $addr): bool
{
	if(ctype_alnum(str_replace(' ', '', $addr)))
	{
		return true;
	}
	$_SESSION['addresserror'] = "Invalid address format";
	return false;
}


function isYearValid(int $year): bool
{
	$MIN = 2016;
	$MAX = 2018;
	if($year >= $MIN && $year <= $MAX)
	{
		return true;
	}
	$_SESSION['yearerror'] = "Invalid year choosen";
	return false;
}

function isLoginEmailNotDuplicate(string $email)
{
	$count = 0;
	// get csv for password pair
	$row = 1;
	if (($handle = fopen("procom_users.csv", "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{
			//if(array_key_exists(key, $))
			//$num = count($data);
			
			if($email == $data[0])
			{
				// found email
				$count++;
				
			}
		}
		// not found/valid
		fclose($handle);

		//var_dump($count);
		if($count == 1)
		{
			return 1;
		}
		if($count == 0 || $count < 1)
		{ // found nothing or is dupe
			return false;
		}

	}
}*/


/**
 * 
 */
class Validate
{
	
	function __construct()
	{
		# c idk what to do with this 
	}

	function areCredentialsValid(array $user_info): bool 
	{
		if(!is_array($user_info))
		{
			// Chaaa, no array found 😔
			return false;
		}
		// csv stuff

		if(!isset($user_info) || !isset($user_info) ||
			empty($user_info) || empty($user_info))
		{
			return false;
		}

		include_once 'Database.php';

		$lilDatabase = new Database();
		$conn = $lilDatabase->getDbConnection();

		$email = $user_info[0];
		$password = $user_info[1];

		$stmt = $conn->prepare("SELECT passw, status FROM procom_users WHERE email=?");
		$stmt->bind_param("s", $email);
		
		$stmt->execute();

		$rc = $stmt->bind_result($retrivedPass,$status);

		if($stmt->fetch())
		{
			// found email

		  	// check if user password is correct
			if($user_info[1] == $retrivedPass)
			{
				// haha password found 😏 
				$lilDatabase->closeDbConnection();
				return true;	
			}	
		}
		else 
		{
			// database either failed to connect or did not find email
			$lilDatabase->closeDbConnection();
			return false;
		}
		$stmt->close();
		$conn->close();
		return false;
	}

	function isEmailValid($email): bool
	{
		//format bad
		if (!filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			$GLOBALS['err_msg'] .= " Invalid email format";
			$_SESSION['emailerror'] = "Invalid email format";// bad way
			return false; 
		}
		
		return true;
	}

	function isPasswordValid($password): bool
	{
		// length
		$MIN = 8;
		if (!(strlen($password) >= $MIN))
		{
			$GLOBALS['err_msg'] .= " Password length must at least 8";
			return false;
		}
		//  alphanurmeric
		//if(preg_match('/[^a-z_\-0-9]/i', $password))
		if(!ctype_alnum($password))
		{
			$GLOBALS['err_msg'] .= " Password should contain only alphanumeric characters";
			return false;
		}
		
		//  alphanurmeric
		if(!preg_match('~[0-9]~', $password))
		{
			$GLOBALS['err_msg'] .= " Password must have at least 1 number";
			return false;
		}
		
		return true;
	}

	function isIdValid(string $id): bool
	{
		//return ((strlen($id) >= 8) && ($id[0] == 4));

		if((strlen($id) >= 8) && ($id[0] == 4))
		{
			return true;
		}

		//check if ID is not dupe.

		$_SESSION['stdntiderror'] = "Invalid ID format";
		return false;
	}

	// The first and last names must be characters only
	function isNameValid(string $name): bool
	{
		if(ctype_alpha($name))
		{
			return true;
		}
		// handled session in manageStudent
		return false;
	}

	// The address must be only alphanumeric characters and spaces
	function isAddressValid(string $addr): bool
	{
		if(ctype_alnum(str_replace(' ', '', $addr)))
		{
			return true;
		}
		$_SESSION['addresserror'] = "Invalid address format";
		return false;
	}

	
	function isYearValid(int $year): bool
	{
		$MIN = 2016;
		$MAX = 2018;
		if($year >= $MIN && $year <= $MAX)
		{
			return true;
		}
		$_SESSION['yearerror'] = "Invalid year choosen";
		return false;
	}

}
/*
$test = new Validate();
$val = $test->areCredentialsValid(array("test.man@test.com","password1234"));
var_dump($val);
*/
?>