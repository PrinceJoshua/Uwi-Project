<?php

if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

include 'Authenticate.php';
$lilAuthenticate = new Authenticate();
if(!$lilAuthenticate->isUserLoggedIn())
{
	// HOME FA YOUUU 🏠 
	header("Location: index.php");
	die();
}

include 'header.php';
?>

		    <div class="content">
       		<a href="console.php">Click Here To Get Back To Console</a>
	        <h2 class="text-center">Students</h2>
        	<nav>

        		<ul id="stdnt_menu">
        			<a href="students.php?year=2016" class="stdnt_menu_item left 
	        		<?php 
	        			if(isset($_GET['year']))
	    				{
	    					if($_GET['year'] == 2016)
	    					echo "stdnt_menu_active";
	    				} 
	        		?>
	        		"><li>2016</li></a>
        			<a href="students.php?year=2017" class="stdnt_menu_item left
	        		<?php 
	        			if(isset($_GET['year']))
	    				{
	    					if($_GET['year'] == 2017)
	    					echo "stdnt_menu_active";
	    				} 
	        		?>
	        		"><li>2017</li></a>
        			<a href="students.php?year=2018" class="stdnt_menu_item left 

	        		<?php 
	        			if(!isset($_GET['year']))
	    				{
	    					echo "stdnt_menu_active";
	    				}
	    				elseif (isset($_GET['year'])) {
	    					if($_GET['year'] == 2018)
	    					echo "stdnt_menu_active";
	    				}
	        		?>
	        		"><li>	2018</li></a>
					<a href="newStudent.php" class="stdnt_menu_item_ignore right"><li>New Student</li></a>
        		</ul>
        	</nav>
					<br>
					<br>
					<div class="my-responsivme-table">
						<p class="text_green">
							<?php 
						 		if(isset($_SESSION['deletemsg']))
								{
									echo "".$_SESSION['deletemsg'];
									unset($_SESSION['deletemsg']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}
						 	?>
						 </p>
						<table class="table" id="stdnt-table" ><!--onload="loadData()"-->
							<thead>
								<!--
								<tr>
									<th>Student ID</th>
									<th>First Name</th>
									<th>Last Name</th>
									<th>Email</th>
								</tr>
								-->
							</thead>
							<tbody id="student_tbody">
								<?php

								if(isset($_GET['year']))
								{
									include 'getStudentByYearForJS.php';
								}
								else
								{
									$_GET['year'] = 2018;
									include 'getStudentByYearForJS.php';
								}
								?>
							</tbody>
						</table>
					</div>
					<br>
		    </div>
		</div>
	</body>
	<script src="javascript/helper.js"></script>
</html>