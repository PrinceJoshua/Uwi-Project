<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

include 'Authenticate.php';
$lilAuthenticate = new Authenticate();
if(!$lilAuthenticate->isUserLoggedIn())
{
	// HOME FA YOUUU 🏠 
	header("Location: index.php");
	die();
}

include 'header.php';
?>

		    <div class="content">
       			<a href="console.php">Click Here To Get Back To Console</a>
	        
		        <h2 class="text-center">Courses</h2>
				

	        	<nav>
	        		<ul id="stdnt_menu"><!--
	        			<a href="#2016" class="stdnt_menu_item left"><li>2016</li></a>
	        			<a href="#2017" class="stdnt_menu_item left"><li>2017</li></a>
	        			<a href="#2018" class="stdnt_menu_item left stdnt_menu_active"><li>2018</li></a>-->
								<a href="#" class="stdnt_menu_item_ignore right" disabled><li>New Courses</li></a>
	        		</ul>
	        	</nav>
	        	<br>
				<div class="my-responsivme-table">
					<table class="table" id="stdnt-table" ><!--onload="loadData()"-->
						<thead>
							<!--
							<tr>
								<th>Student ID</th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Email</th>
							</tr>
							-->
						</thead>
						<tbody>
							<?php

							include 'viewCourses.php';
							$jsonData = getCourses();
							echo viewCourses($jsonData);

							?>
						</tbody>
					</table>
				</div>
				<br>
		    </div>
		</div>
	</body>
	<script src="javascript/helper.js"></script>
</html>