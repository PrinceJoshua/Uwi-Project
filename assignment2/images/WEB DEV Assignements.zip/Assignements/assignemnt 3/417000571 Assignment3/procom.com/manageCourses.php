<?php
var_dump($_GET);
/*
if (isset($_GET['id']) && isset($_GET['action']))
{	
	// in here you either update student ot delete student 

	// prepare selected data
	$student_data = getOneCourse($_GET['id']);
	if($_GET['action'] == "edit")
	{
		// get edit page
		include 'updateCourse.php';
	}

	if($_GET['action'] === "del")
	{
		// get delete page
		include 'deleteCourse.php';
		
	}

}*/

?>