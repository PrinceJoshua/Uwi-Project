<?php
//var_dump($student_data);
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

include 'Authenticate.php';
$lilAuthenticate = new Authenticate();
if(!$lilAuthenticate->isUserLoggedIn())
{
	// HOME FA YOUUU 🏠 
	header("Location: index.php");
	die();
}

include 'header.php';



?>
		    
		    <div class="content">
	        <h2 class="text-center">Update Student: <b><?php echo $student_data['fname']." ".$student_data['lname'] ?></b></h2>
        	
				<form action="update.php" method="post" >
					<input type="hidden" id="isJSGood" name="isJSGood" value="0" />
					<input type="hidden" id="hiddenid" name="hiddenid" value="<?php echo $student_data['studentid'] ?>" />
					<div class="form-item">
						<label class="form-label">Student ID:</label>
						<input class="registration-input form-txtbox" value="<?php echo $student_data['studentid'] ?>" type="text" id="stntid" name="stntid" placeholder="" disabled/>
						<div id="error-msg-container-stdntid">
							<?php
								/*if(isset($_SESSION['stdntiderror']))
								{
									echo "<span class='error-msg-text'>";
									echo "".$_SESSION['stdntiderror'];
									echo "</span>";
									unset($_SESSION['stdntiderror']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}*/
							?>
						</div>
					</div>
					<div class="form-item">
						<label class="form-label">Firstname:</label>
						<input class="registration-input form-txtbox" value="<?php echo $student_data['fname'] ?>" type="text" class="form-txtbox" id="fname" name="fname" placeholder=""/>
						<div id="error-msg-container-fname">
							<?php
								if(isset($_SESSION['fnameerror']))
								{
									echo "<span class='error-msg-text'>";
									echo "".$_SESSION['fnameerror'];
									echo "</span>";
									unset($_SESSION['fnameerror']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}
							?>
						</div>
					</div>
					<div class="form-item">
						<label class="form-label">Lastname:</label>
						<input class="registration-input form-txtbox" value="<?php echo $student_data['lname'] ?>" type="text" class="form-txtbox" id="lname" name="lname" placeholder=""/>
						<div id="error-msg-container-lname">
							<?php
								if(isset($_SESSION['lnameerror']))
								{
									echo "<span class='error-msg-text'>";
									echo "".$_SESSION['lnameerror'];
									echo "</span>";
									unset($_SESSION['lnameerror']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}
							?>
						</div>
					</div>
					<div class="form-item">
						<label class="form-label">Email:</label>
						<input class="registration-input form-txtbox" value="<?php echo $student_data['email'] ?>" type="text" class="form-txtbox" id="email" name="email" placeholder=""/>
						<div id="error-msg-container-email">
							<?php
								if(isset($_SESSION['emailerror']))
								{
									echo "<span class='error-msg-text'>";
									echo "".$_SESSION['emailerror'];
									echo "</span>";
									unset($_SESSION['emailerror']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}
							?>
						</div>
					</div>
					<div class="form-item">
						<label class="form-label">Address:</label>
						<textarea class="registration-input form-txtbox" rows="4" cols="50" class="form-txtbox" id="address" name="address" ><?php echo $student_data['address'] ?></textarea>
						<div id="error-msg-container-address">
							<?php
								if(isset($_SESSION['addresserror']))
								{
									echo "<span class='error-msg-text'>";
									echo "".$_SESSION['addresserror'];
									echo "</span>";
									unset($_SESSION['addresserror']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}
							?>
						</div>
					</div>
					<div class="form-item">
						<label class="form-label">Year:</label>
						<select class="registration-input form-txtbox" class="form-txtbox" id="year" name="year" >
							<option value="2018" <?php if($student_data['year'] === "2018"){echo "selected='selected'";} var_dump($student_data['year']); ?> >2018</option>
							<option value="2017" <?php if($student_data['year'] === "2017"){echo "selected='selected'";} ?> >2017</option>
							<option value="2016" <?php if($student_data['year'] === "2016"){echo "selected='selected'";} ?> >2016</option>
						</select>
						<div id="error-msg-container-year">
							<?php
								if(isset($_SESSION['addresserror']))
								{
									echo "<span class='error-msg-text'>";
									echo "".$_SESSION['addresserror'];
									echo "</span>";
									unset($_SESSION['addresserror']);	
								}
								else
								{
									//var_dump($_SESSION['stdntiderror']);
								}
							?>
						</div>
					</div>
					<div class="form-item">
						<button id="update-btn" class="button-space" type="submit">Update</button>
						<!--<button id="cancel-btn" class="button-space" type="button">Cancel</button>-->
						<a href="students.php" id="cancel-btn" class="button-space" type="button">Cancel</a>
					</div>
					<div id="add_successful">
						<?php
							if(isset($_SESSION['successmsg']))
							{
								echo "<p>";
								echo "".$_SESSION['successmsg'];
								echo "</p>";
								unset($_SESSION['successmsg']);	
							}
							else
							{
								//var_dump($_SESSION['stdntiderror']);
							}
						?>
					</div>
					
					<br>
				</form>
		    </div>
		</div>
		
		<script>
			function updateStudent(data)
			{
				// check user login info
				document.getElementById("update-btn").setAttribute("type","submit");
				document.getElementById("update-btn").click();

				console.log("new student data = "+data);
				console.log("new student data = "+data[0]['id']);
				console.log("new student data = "+data[0]['fname']);
				console.log("new student data = "+data[0]['lname']);
				console.log("new student data = "+data[0]["email"]);
				console.log("new student data = "+data[0]["address"]);
				
				var jsonData = JSON.stringify(data);
				if(localStorage.getItem("student_table_data") === null)
				{
					// create new localStorage
					console.log("first entry");
					localStorage.setItem("student_table_data", jsonData);
					
				}
				else
				{
					console.log("another entry")
					var retrievedJsonData = JSON.parse(localStorage.getItem("student_table_data"));
					retrievedJsonData.push(data[0]);
					localStorage.setItem("student_table_data", JSON.stringify(retrievedJsonData));
				}
				// sucessfully added data to table msg here
				var mydiv = document.getElementById("add_successful");
				mydiv.innerHTML = "";
				p1 = document.createElement('p');
				p1.innerHTML = "Successfully added new Student";
				mydiv.appendChild(p1);
				console.log("successfully added student to local table");
			}
			
			function validateStudentID(userid)
			{
				var stdnt_msg =  document.getElementById('error-msg-container-stdntid');
				stdnt_msg.innerHTML ="";
				
				console.log(userid);
				var status = true;
				if(userid.toString().length != 9)
				{
					console.log("ID Length not 9");
					status = false;
				}
				
				if(userid.toString()[0] != 4)
				{
					console.log("ID does not begin with 4 ");
					status = false;
				} 
				
				if(isNaN(userid))
				{
					console.log("ID is not Integer ");
					status = false;
				}
				
				if(!status)
				{
					var iderror = document.createElement("span");
					iderror.classList.add("error-msg-text");
					iderror.innerHTML = "Error: invalid student id format";
					stdnt_msg.appendChild(iderror);
				}
				
				return status;
			}
			
			function validateFirstName(fname)
			{
				var fname_msg =  document.getElementById('error-msg-container-fname');
				fname_msg.innerHTML ="";
				var status = true;
				if(!isNameValid(fname))
				{
					console.log("reeeeee");
					var fnameerror = document.createElement("span");
					fnameerror.classList.add("error-msg-text");
					fnameerror.innerHTML = "Error: invalid first name format";
					fname_msg.appendChild(fnameerror);
					status = false;
				}
				
				return status;
			}
			
			function validateLastName(lname)
			{
				var lname_msg =  document.getElementById('error-msg-container-lname');
				lname_msg.innerHTML ="";
				var status = true;
				if(!isNameValid(lname))
				{
					var lnameerror = document.createElement("span");
					lnameerror.classList.add("error-msg-text");
					lnameerror.innerHTML = "Error: invalid last name format";
					lname_msg.appendChild(lnameerror);
					status = false;
				}
				return status;
			}
			
			function isNameValid(name)
			{
				var status = true;
				var validLetters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
				if(name == null || name.length === 0 || !isNaN(name))
				{
					console.log("invalid name "+name);
					status = false;
				}
				else
				{
					console.log(isNaN(name)+"valid name "+name);
				}
				return status;
			}
			
			function validateEmail(useremail)
			{
				var email_msg =  document.getElementById('error-msg-container-email');
				email_msg.innerHTML ="";
				var status = true;
				var reEmail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				//re.test()
				//alert(reEmail); 
				if(!useremail.match(reEmail)) 
				{
					var emailerror = document.createElement("span");
					emailerror.classList.add("error-msg-text");
					emailerror.innerHTML = "Error: invalid email format";
					email_msg.appendChild(emailerror);
					status = false;
				}
				return status;
			}
			
			function validateAddress(useraddress)
			{
				var address_msg =  document.getElementById('error-msg-container-address');
				address_msg.innerHTML ="";
				var status = true;

				var reAddress = /^[a-z\d\-_\s]+$/i;
				if(useraddress && useraddress.toString().match(reAddress) && useraddress.length != 0)
				{
					status = true;
				} 
				else
				{
					console.log("uu "+useraddress.toString().match(reAddress));
					var addresserror = document.createElement("span");
					addresserror.classList.add("error-msg-text");
					addresserror.innerHTML = "Error: Enter Address";
					address_msg.appendChild(addresserror);
					status = false;
				}
				return status;
			}
			
			function validateYear(useryear)
			{
				var year_msg =  document.getElementById('error-msg-container-year');
				year_msg.innerHTML ="";
				var status = true;
				useryear = parseInt(useryear);
				if(isNaN(useryear) || !((useryear >= 2016) && (useryear <= 2018)))
				{
					// somehow year was not entered correctly
					console.log("NaN year = "+useryear.toString());
					var yearerror = document.createElement("span");
					yearerror.classList.add("error-msg-text");
					yearerror.innerHTML = "Error: "+useryear+" is invalid";
					year_msg.appendChild(yearerror);
					status = false;
				}
				return status;
			}
			
			// tab thing
			updatebtn = document.getElementById('update-btn');
			if(updatebtn)
			{
				updatebtn.addEventListener('click', function(){
					// get all form input
					var stntid = document.getElementById('stntid');
					var fname = document.getElementById('fname');
					var lname = document.getElementById('lname');
					var email = document.getElementById('email');
					var address = document.getElementById('address');
					var year = document.getElementById('year');
					
					// get input value of elements
					var stntid_value = stntid.value;
					var fname_value = fname.value;
					var lname_value = lname.value;
					var email_value =  email.value;
					var address_value = address.value;
					var year_value = year.value;
					
					// debugging
					console.log(
					stntid_value+" "+
					fname_value+" "+
						lname_value+" "+
						email_value+" "+
						address_value+" "+
						year_value
					);
					
					// validate all input s =  status/boolean value 
					var s1 = validateStudentID(parseInt(stntid_value));
					var s2 = validateFirstName(fname_value);
					var s3 = validateLastName(lname_value);
					var s4 = validateEmail(email_value);
					var s5 = validateAddress(address_value);
					var s6 = validateYear(year_value);
					
					if(s1 && s2 && s3 && s4 && s5 && s6)
					{
						document.getElementById("update-btn").setAttribute("type","submit");
						document.getElementById("update-btn").click();
						// send user to php
						var userInput = new Array();
						//userInput = [stntid_value,fname_value,lname_value,email_value,address_value];
						/* OLD WAY MIGHT BE ABLE TO DELETE
						userInput = [
							{id:stntid_value,fname:fname_value,lname:lname_value,email:email_value,address:address_value,year:getRandomInt(2016,2018)}
							];*/
						userInput = [
							{id:stntid_value,fname:fname_value,lname:lname_value,email:email_value,address:address_value,year:year_value}
							];
						updateStudent(userInput);
					}
					
				});
			}
			
			function getRandomInt(min, max) 
			{
					min = Math.ceil(min);
					max = Math.floor(max);
					return Math.floor(Math.random() * (max - min + 1)) + min;
			}
		document.getElementById("isJSGood").value = "1";
		document.getElementById("update-btn").setAttribute("type","button");
				
		</script>
	</body>
</html>