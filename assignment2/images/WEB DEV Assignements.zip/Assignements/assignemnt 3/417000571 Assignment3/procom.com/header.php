<?php
//include 'Authenticate.php';
$lilAuthenticate = new Authenticate();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>PROCOMS Console Page</title>
		<link href="style.css" rel="stylesheet" type="text/css" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="javascript/helper.js"></script>
	</head>
	<body>
		<div class="page-container">
		    <nav>
		        <h2 class="page-title">Programme: M.So. Information Technology</h2>
		        <!--<div class="">
                    <img onclick="menuClick()" id="ham-icon" src="images/menu-min-min.png" />
                    <div class="menu-list" id="forToggle" style="display: none;">
                        <a href="#">Account</a>
                        <a href="#">Setting</a>
                        <a onclick="logOut()" href="logout.php">Log Out</a>
                    </div>
		        </div>-->
		        <!-- start burger menu -->
		        <ul id="menu">
			        <li class="boxylook"><i style="display: block;" class="boxylook" href=""></i>
					   <ul id="user-info">
					      <li><a href="#">Account</a></li>
					      <li><a href="#">Setting</a></li>
					      <li><a href="logout.php">Log Out</a></li>
					   </ul>
					</li>
		        </ul>
		        <!-- end burger menu -->

				<!-- start user login info-->
		        <ul >
		        
					<!--<li class="user-item">User: <span id="username"></span></li>
					<li class="user-item">Role: <span id="userrole"></span></li>-->
					<li class="user-item"><span id="username"><?php echo "User: ".$lilAuthenticate->getUserInfo("fname")." ".$lilAuthenticate->getUserInfo('lname'); ?></span></li>
					<li class="user-item"><span id="userrole"><?php echo "Role: ".$lilAuthenticate->getUserInfo('role'); ?></span></li>
				</ul>
				<!-- end user login info-->
		    </nav>
		    <br>
		    <br>