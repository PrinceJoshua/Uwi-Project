<?php
session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>PROCOMS Login Page</title>
		<link href="style.css" rel="stylesheet" type="text/css" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	</head>
	<body>
		<div class="login-container">
		<form action="login.php" method="post">
			<h2>Programme Coordinator Management System</h2>
			<h2>M.So. Information Technology</h2>
			<br>
			<br>
			<input id="isJSGood" name="isJSGood" type="hidden" value="0"/>
			<div class="form-item">
				<label class="form-label">Email</label>
				<input type="text" id="email" name="email" value="" placeholder="Email Address"/>
			</div>
			<div class="form-item">
				<label class="form-label">Password</label>
				<input type="password" id="password" name="password" value="" placeholder="Password"/>
			</div>
			<div class="form-item">
				<button id="login-button" type="submit">Sign In</button>
                <!--<input type="submit" id="login-button" value="Sign In" />--> 
		    </div>
			<div class="form-item">
				<a href="#">Forgot Password</a>
			</div>
			
            <div id="error-msg-container">
			    <?php
					if(isset($_SESSION['errormsg']))
					{
						echo "<span class='error-msg-text'>";
						echo "".$_SESSION['errormsg'];
						echo "</div>";
						unset($_SESSION['errormsg']);	
					}
					else
					{
						//var_dump($_SESSION['errormsg']);
					}
				?>
			</div>
			<br>
		</form>
		<script>
        var myBr = document.createElement("br");
        
        var msg =  document.getElementById('error-msg-container');
        function checkEmail(theEmail) 
        {
            var reEmail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            //re.test()
            //alert(reEmail); 
            if(!theEmail.match(reEmail)) 
            {
                //msg.append("Invalid email address");
                var mySpan1 = document.createElement("span");
                mySpan1.classList.add("error-msg-text");
                mySpan1.innerHTML = "Invalid email address";
                msg.appendChild(mySpan1);
                //alert("Invalid email address"); // modify
                return false;
            }

            return true;
        }
        function checkPassword(thePassword)
        {
            var passwordIsGood = true;
            if(thePassword.length < 8)
            { // length
                //msg.append();
                var mySpan2 = document.createElement("span");
                mySpan2.classList.add("error-msg-text");
                mySpan2.innerHTML = "Password length must at least 8";
                msg.appendChild(mySpan2);
                passwordIsGood = false;
            }
            if( thePassword.match(/[^0-9a-z]/i))
            { // contains only alphanumeric characters 
                //msg.append("Password contains only alphanumeric characters");
                var mySpan3 = document.createElement("span");
                mySpan3.classList.add("error-msg-text");
                mySpan3.innerHTML = "Password should contain only alphanumeric characters";
                msg.appendChild(mySpan3);
                // msg.appendChild(myBr);
                passwordIsGood = false;
            }
            if(!thePassword.match(/[0-9]/))
            { // at least one number
                //msg.append("Password must have at least 1 number");
                var mySpan4 = document.createElement("span");
                mySpan4.classList.add("error-msg-text");
                mySpan4.innerHTML = "Password must have at least 1 number";
                msg.appendChild(mySpan4);
                //msg.appendChild(myBr);
                passwordIsGood = false;
            }
            
            return passwordIsGood;
        }
        
        function checkUser(theUser)
        {  
            // check user login info
			document.getElementById("login-button").setAttribute("type","submit");
			document.getElementById("login-button").click();
			
			if(localStorage.getItem("login_table") === null)
			{
				// no accounts exist
				/*
				console.log("no account was found");
				var wrong = document.createElement("span");
				wrong.classList.add("error-msg-text");
				wrong.innerHTML = "Oops, wrong email or password 😔";
				msg.appendChild(wrong);
				return false;
				*/
				
				// temp account created
				var allinfo = [{email:"john.doe@uwistaff.com",password:"123isthepassworD",role:"Administrator",fname:"John",lname:"Doe"}];
				console.log("raw dic"+allinfo);
				var jsonData = JSON.stringify(allinfo);
				console.log("String json "+jsonData);
				localStorage.setItem("login_table", jsonData);
				//recursively call checkUser
				checkUser(theUser);
				//return true to simulate that it works
				return true;
			} else
			{
				//some accounts exist
				var retrievedJsonData = JSON.parse(localStorage.getItem("login_table"));
				/*retrievedJsonData.some(function(arrayvalue){
					return
				})*/
				/*
				var result = retrievedJsonData.filter(obj => {
					console.log("Meme 1 "+obj['email']);
					console.log("Meme 1 "+theUser[0]);
					return obj['email'] === theUser[0];
					
				});*/
				/*var result = retrievedJsonData.find(obj => obj['email'] === theUser[0]);
				console.log("Meme 2 "+result);
				*/
				for(var i = 0; i<retrievedJsonData.length;i++)
				{
					var someEmail = retrievedJsonData[i]['email'];
					var somePass = retrievedJsonData[i]['password'];
					console.log("Comparing input: "+theUser[0]+" to Storage: "+someEmail+" boolean value = "+(someEmail === theUser[0]));
					console.log("Comparing input: "+theUser[1]+" to Storage: "+somePass+" boolean value = "+(somePass === theUser[1]));
					
					// looking for that email
					if(someEmail == theUser[0])
					//if(someEmail.localeCompare(theUser[0]) && somePass.localeCompare(theUser[1]))
					{
						//found email but is password correct
						if(somePass == theUser[1])
						{
							// password correct 👍
							console.log("winner winner, chicken dinner");
							sessionStorage.setItem("fullname", retrievedJsonData[i]['fname']+" "+retrievedJsonData[i]['lname']);
							sessionStorage.setItem("role", retrievedJsonData[i]['role']);
							// end forloop
							return true;
						} else 
						{
							// end forloop bad password
							console.log("Loser, Loser, Nyquil Boozer");
							var wrong = document.createElement("span");
							wrong.classList.add("error-msg-text");
							wrong.innerHTML = "Oops, wrong email or password 😔";
							msg.appendChild(wrong);
							return false;
						}
					}
				}
				var wrong = document.createElement("span");
				wrong.classList.add("error-msg-text");
				wrong.innerHTML = "Oops, wrong email or password 😔";
				msg.appendChild(wrong);
				// never found account
				return false;
			}
			//console.log(retrievedJsonData);
        }
            
        loginbtn = document.getElementById('login-button');
        if(loginbtn)
        {
            loginbtn.addEventListener('click', function(){
            msg.innerHTML="" //clear error nsg box
            email = document.getElementById('email');
            var value1 = email.value;
            //checkEmail(value1);

            password = document.getElementById('password');
            var value2 = password.value;
            //checkPassword(value2);
            var isValid = (checkEmail(value1) && checkPassword(value2));
            
            if(isValid)
            {
                
                //
                /*
                var mySpan5 = document.createElement("span");
                mySpan5.classList.add("error-msg-text");
                mySpan5.innerHTML = "tesst";
                msg.appendChild(mySpan5);*/
                
                var allinfo = [value1,value2];
                var status2 = checkUser(allinfo);
                if(status2)
								{
									window.stop();
									window.location.replace("console.html");
								}
            }

            });
        } else
        {
            //alert("cant get email element")
        }
			/*
			document.getElementById('addLinks').onkeypress=function(e){
				if(e.keyCode==13){
						document.getElementById('linkadd').click();
				}
			}*/
    </script>
	</body>
</html>
<script src="javascript/checkjs.js"></script>