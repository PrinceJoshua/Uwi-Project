<?php

if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

// returns the student data from the CSV file as a JSON string
function getStudents(string $year) : string
{
	include_once 'Database.php';
	$lilDatabase = new Database();
	$conn = $lilDatabase->getDbConnection();

	$student_list = array();
	

	$sql_line = "SELECT id, fname, lname, email, address FROM students WHERE year = ? ORDER BY id ASC";

	if($stmt = $conn->prepare($sql_line))
	{
		$stmt->bind_param('i',$year);
		$stmt->execute();
	   	$result = $stmt->get_result();

		if( $result->num_rows > 0 )
		{
		   
		   while ($row = $result->fetch_assoc())
		   {
		        array_push($student_list, $row);
		        /*$student_list[] = array("id"=>$row[0],
			 	 "fname"=>$row[1], 
			 	  "lname"=>$row[2],
			 	   "email"=>$row[3],
			        "address"=>$row[4]);*/
		        //echo "<br>";
		        //var_dump($row);
		        //echo "<br>";
	    	}

		}
		else
		{
			// failed to open or table empty
			return "";
		}
	}
	/*
	//fgetcsv
	$row = 1;
	if (($handle = fopen("students.csv", "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{
			// not empty then do the thing
			
			if($data[0] != NULL)
			{
				// if year match pull
				if($data[5] == $year)
				{
					$student_list[] = array("id"=>$data[0],
				 	 "fname"=>$data[1], 
				 	  "lname"=>$data[2],
				 	   "email"=>$data[3],
				        "address"=>$data[4]);
				}
				$row++;
			}
		}
	}
	echo "</tr>";
	if($row == 1)
	{
		// failed to open or table empty
		//echo "";
		return "";
	}
	*/
	$student_list = json_encode($student_list);
	//var_dump($student_list);
	return $student_list;
}

// string that takes the JSON string and formats
// the student information as an HTML string for display in the browser.
function viewStudents(string $data) : string
{

	$htmlString = "";
	$data = json_decode($data);
	
	if(!empty($data))
	{
		
		//*
		for ($i = 0; $i < count($data); ++$i) 
		{
			$htmlString .= "<tr>".
			"<td><a href='manageStudents.php?id=".$data[$i]->id."&action=edit' class='stdnt_btn blue' onclick='updateStudent(".$data[$i]->id.")'>Edit</a></td>".
			"<td><a href='manageStudents.php?id=".$data[$i]->id."&action=del' class='stdnt_btn red' onclick='deleteStudent(".$data[$i]->id.")'>Delete</a></td>".
	        "<td>".$data[$i]->id."</td>".
	        "<td>".$data[$i]->fname."</td>".
	        "<td>".$data[$i]->lname."</td>".
	        "<td>".$data[$i]->email."</td>".
	        "<td>".$data[$i]->address."</td>".
			"</tr>";
	    }
	    //*/
	    /*
	    foreach ($data as $key => $object)
	    {
		    var_dump($data-['id']);
		}*/
	} else
	{
		$htmlString .= "<tr>".
	        "<td colspan=\"7\">No data found.</td>".
	        "</tr>";
	}
	return $htmlString;
}

?>