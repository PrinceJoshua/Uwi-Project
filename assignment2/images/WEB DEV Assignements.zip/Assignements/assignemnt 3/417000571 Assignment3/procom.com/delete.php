<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

function deleteStudent(int $someId)
{
	include_once 'Database.php';
	$lilDatabase = new Database();
	$conn = $lilDatabase->getDbConnection();

	if($stmt = $conn->prepare("DELETE FROM students WHERE id = ? LIMIT 1"))
	{
		$stmt->bind_param('i',$someId);
		$stmt->execute();
	} else
	{

	}

	$lilDatabase->closeDbConnection();
	$stmt->close();
	
	fclose($handle);
	$_SESSION['deletemsg'] = "Deleted student with ID: <b>".$someId."</b>";
	header("Location: students.php");
	die();
}

if(!isset($_POST['hiddenid']))
{
	header("Location: students.php");
	die();
}

if(isset($_POST['hiddenid']))
{
	$stntid = $_POST['hiddenid'];

	include 'validate.php';
	$lilValidate = new Validate();
	$s1 = $lilValidate->isIdValid($stntid);

	if(!$s1)
	{
		var_dump($stntid);
		// sent home with error msg
		header("Location: manageStudents.php?id=".$stntid."&action=del");
		die();
	}
	
	//var_dump($updatedData);
	// deleted csv cause everthing good
	deleteStudent($stntid);
}
?>