<?php
$GLOBALS['newId'] = 0;
// check if post was used theregfore a new student is added to DB
if(isset($_POST['isJSGood']))
{

	$s1 = true;
	$s2 = true;
	$s3 = true;
	$s4 = true;
	$s5 = true;
	include 'validate.php';
	$lilValidate = new Validate();
	// get id
	do
	{
		$GLOBALS['newId'] = createNewID();
		$s5 = $lilValidate->isIdValid($GLOBALS['newId']);
	} while($s5 == false);

	//check if javscript is not on
	if($_POST['isJSGood'] != 1)
	{

		
		// javascript validation was off
		// do php validation
		//echo "string";
		
		$s1 = $lilValidate->isNameValid($_POST['fname']);
		$s2 = $lilValidate->isNameValid($_POST['lname']);
		$s3 = $lilValidate->isAddressValid($_POST['address']);
		$s4 = $lilValidate->isEmailValid($_POST['email']);
		$s6 = $lilValidate->isYearValid($_POST['year']);
		if(!$s1 ||
		 !$s2 ||
		  !$s3 ||
		   !$s4 ||
		    !$s5 ||
		     !$s6)
		{

			// handle specifically here and not in validate
			if(!$s1)
			{
				$_SESSION["fnameerror"] = "Invalid first name entry";
			}
			if(!$s2)
			{
				$_SESSION["lnameerror"] = "Invalid last name entry";
			}

			

			// bad data send to 
			//$_SESSION["yearerror"]=$GLOBALS['err_msg'];
			var_dump($GLOBALS['err_msg']);
			header("Location: newStudent.php");
			die();

		}
	}
	//var_dump($_POST);

	//newArray = array("stntid"=>$GLOBALS['newId'],);
	//var_dump($GLOBALS['newId']);
	$_POST = array('stntid' => $GLOBALS['newId']) + $_POST; 
	//$arr1 = array('key0' => 'value0') + $arr1;
	//var_dump($_POST);
	newStudent($_POST);
	
	// some session to say successful update
	$_SESSION["successmsg"] = "Successfully added new student with ID: <b>".$_POST['stntid']."</b>";
	header("Location: newStudent.php");
	die();
	// postivive send back to newstudents.php
} elseif (isset($_GET['id']) && isset($_GET['action'])) {	
	// in here you either update student ot delete student 

	// prepare selected data
	$student_data = getOneStudent($_GET['id']);
	if($_GET['action'] == "edit")
	{
		// get edit page
		include 'updateStudent.php';
	}

	if($_GET['action'] === "del")
	{
		// get delete page
		include 'deleteStudent.php';
		
	}

}

function getOneStudent($search_id) :array
{
	include_once 'Database.php';
	$lilDatabase = new Database();
	$conn = $lilDatabase->getDbConnection();

	$stmt = $conn->prepare("SELECT id, fname, lname, email, address, year FROM students WHERE id=?");
	$stmt->bind_param("i", $search_id);
	$stmt->execute();

	$rc = $stmt->bind_result($rid, $rfname, $rlname, $remail, $raddress, $ryear);

	if($stmt->fetch())
	{
		$student_data = array("studentid"=>$rid,
		 "fname"=>$rfname,
		  "lname"=>$rlname,
		   "email"=>$remail,
		    "address"=>$raddress, 
		     "year"=>$ryear);
		$lilDatabase->closeDbConnection();
		$stmt->close();
		return $student_data;
	} else
	{
		$student_data = array("studentid"=>"null",
		 "fname"=>"null",
		  "lname"=>"null",
		   "email"=>"null",
		    "address"=>"null", 
		     "year"=>"null");  
		$lilDatabase->closeDbConnection();
		$stmt->close();
		return $student_data;
	}	
}

function newStudent(array $data)
{
	unset($data['isJSGood']); // clear javascript status

	include_once 'Database.php';
	$lilDatabase = new Database();
	$conn = $lilDatabase->getDbConnection();


	$stmt = $conn->prepare("INSERT INTO students (id,fname,lname,email,address,year) values (?,?,?,?,?,?)");
	$stmt->bind_param("issssi", $data['stntid'], $data['fname'], $data['lname'], $data['email'], $data['address'], $data['year']);

	//var_dump($data);
	

	$rc = $stmt->execute();
	var_dump($rc);
	if($rc)
	{
		$lilDatabase->closeDbConnection();
		return false;
		
	}
	$stmt->close();
	$conn->close();
		
	/*
	//
	//var_dump($data);
	$handle = fopen("students.csv", "a");
	fputcsv($handle, $data);
	fclose($handle);
	*/
}



function createNewID()
{
	return rand(400000000,499999999);
}
?>