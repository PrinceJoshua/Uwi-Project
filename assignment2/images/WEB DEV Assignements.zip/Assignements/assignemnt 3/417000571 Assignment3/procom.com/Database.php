<?php

class Database
{
	private $conn;

	public function __construct()
	{
		define('hostname', 'localhost');
		define('user', 'root');
		define('password', '');
		define('db_name', 'procom_db');
		$this->conn = new mysqli(hostname, user, password, db_name);
	}

	public function getDbConnection()
	{
		 return $this->conn;
	}
	
	public function closeDbConnection()
	{
		 return $this->conn->close();
	}	

	//public function
}
/*
$lilDatabase = new Database();
var_dump($lilDatabase->getDbConnection());
*/
?>