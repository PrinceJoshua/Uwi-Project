<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

function updateStudent(array $data)
{
	include_once 'Database.php';
	$lilDatabase = new Database();
	$conn = $lilDatabase->getDbConnection();

	if($stmt = $conn->prepare("UPDATE students 
		SET 
		fname = ?,
	 	 lname = ?,
	 	  email = ?,
	 	   address = ?,
	 	    year = ? 
	 	WHERE id = ? LIMIT 1"))
	{
		$stmt->bind_param('ssssii',$data[1],$data[2],$data[3],$data[4],$data[5],$data[0]);
		 //var_dump($stmt);

		/* execute query */
		$stmt->execute();
		
		//var_dump($stmt->affected_rows);
		if($stmt->affected_rows) {
			//echo "Update Successful";
			//ob_start();
			echo "<br><p style='text-align:center;'>Update was successfully for student with ID: <b>".$data[0]."</b></p><br>";
			echo "<a href='students.php' style='text-align:center;display:block;'>You will be Redirect to a new page in 5 seconds to students.php or click here.</a> <br>";
			//ob_end_flush();
			//header("refresh:5;url=students.php");
			
			//header("Location: manageStudents.php?id=".$data[0]."&action=edit");

			header("refresh:5;url=students.php");
			//die();
		} else {
			//echo "Fail to Update Record";
			//header("Location: manageStudents.php?id=".$data[0]."&action=edit");
			echo "<br><p style='text-align:center;'>Failed to push new changes to student with ID:<b>".$data[0]."</b></p><br>";
			echo "<a href='students.php' style='text-align:center;display:block;'>You will be Redirect to a new page in 5 seconds to students.php or click here.</a> <br>";
			//ob_end_flush();
			header("refresh:5;url=students.php");
			//die();
		}
	}

	/*
	$students_data =  array();
	// get all data
	$row = 1;
	if (($handle = fopen("students.csv", "r")) !== FALSE) 
	{
		while (($studentRow = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{
			//$num = count($data2);
			
			
			// found email
			$students_data[] = array("studentid"=>$studentRow[0],
			 "fname"=>$studentRow[1],
			  "lname"=>$studentRow[2],
			   "email"=>$studentRow[3],
			    "address"=>$studentRow[4], 
			     "year"=>$studentRow[5]);   
			//$students_data = json_encode($students_data);
			
			
		//var_dump($students_data);echo "<br>";
			
		}
		// not found/valid
		fclose($handle);
		//var_dump($students_data);
		for ($i=0; $i < sizeof($students_data); $i++) 
		{ 
			#
			//echo "hey ";
			if($data[0] == $students_data[$i]['studentid'])
			{
				$students_data[$i] = $data;
				file_put_contents("students.csv", ""); 

				$handle = fopen("students.csv", "a");

				foreach ($students_data as $row) {
				       fputcsv($handle, $row);
				}
				fclose($handle);
				header("Location: students.php");
				//header("Location: manageStudents.php?id=".$data[0]."&action=edit");
				die();
				break;
			}
		}

	}*/
}

if(!isset($_POST['isJSGood']))
{
	header("Location: students.php");
	die();
}
if(isset($_POST['isJSGood']) ||
 isset($_POST['hiddenid']) ||
  isset($_POST['fname']) ||
   isset($_POST['lname']) ||
    isset($_POST['email']) ||
     isset($_POST['address']) ||
      isset($_POST['year']))
{
	$jstatus = $_POST['isJSGood'];
	$stntid = $_POST['hiddenid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$year = $_POST['year'];

	$updatedData = array($stntid,
		$fname,
		$lname,
		$email,
		$address,
		$year);
	// validate if javascript was off
	if(!$jstatus)
	{
		include 'validate.php';
		$lilValidate = new Validate();
		$s1 = $lilValidate->isIdValid($stntid);
		$s2 = $lilValidate->isNameValid($fname);
		$s3 = $lilValidate->isNameValid($lname);
		$s4 = $lilValidate->isEmailValid($email);
		$s5 = $lilValidate->isAddressValid($address);
		$s6 = $lilValidate->isYearValid($year);

		if(!$s1 || !$s2 || !$s3 || !$s4 || !$s5 || !$s6)
		{
			if(!$s2)
			{
				$_SESSION["fnameerror"] = "Invalid first name entry";
			}
			if(!$s3)
			{
				$_SESSION["lnameerror"] = "Invalid last name entry";
			}
			// sent home with error msg
			//$_SESSION["errormsg"]=$GLOBALS['err_msg'];
			header("Location: manageStudents.php?id=".$stntid."&action=edit");
			die();
		}
	}
	//var_dump($updatedData);
	// update csv cause everthing good
	updateStudent($updatedData);
}
?>