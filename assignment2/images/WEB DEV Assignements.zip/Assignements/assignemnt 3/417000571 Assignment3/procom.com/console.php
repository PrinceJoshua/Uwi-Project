<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

include 'Authenticate.php';
$lilAuthenticate = new Authenticate();
if(!$lilAuthenticate->isUserLoggedIn())
{
	// HOME FA YOUUU 🏠 
	header("Location: index.php");
	die();
}

include 'header.php';
?>
			<div class="content">
		        <a href="students.php" class="myBox">Students</a>
		        <a href="courses.php" class="myBox">Courses</a>
		        <a href="#" class="myBox">Correspondence</a>
		        <a href="#" class="myBox">Lectures</a>
		        <a href="#" class="myBox">Schedule</a>
		        <a href="#" class="myBox">Documentation</a>
		    </div>
		</div>
	</body>
</html>