<?php

if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

// returns the student data from the CSV file as a JSON string
function getCourses() : string
{
	$course_list = array();
	//fgetcsv
	$row = 1;
	if (($handle = fopen("courses.csv", "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
		{
			// not empty then do the thing
			
			if($data[0] != NULL)
			{
				$course_list[] = array("id"=>$data[0],
			 	 "name"=>$data[1]);
				
				$row++;
			}
		}
	}
	if($row == 1)
	{
		// failed to open or table empty
		//echo "";
		return "";
	}

	$course_list = json_encode($course_list);
	//var_dump($course_list);
	return $course_list;
}

// string that takes the JSON string and formats
// the student information as an HTML string for display in the browser.
function viewCourses(string $data) : string
{

	$htmlString = "";
	$data = json_decode($data);
	
	if(!empty($data))
	{
		
		//*
		for ($i = 0; $i < count($data); ++$i) 
		{
			$htmlString .= "<tr>".
			"<td><a href='manageCourses.php?id=".$data[$i]->id."&action=edit' class='stdnt_btn blue' onclick='updateStudent(".$data[$i]->id.")'>Edit</a></td>".
			"<td><a href='manageCourses.php?id=".$data[$i]->id."&action=del' class='stdnt_btn red' onclick='deleteStudent(".$data[$i]->id.")'>Delete</a></td>".
	        "<td>".$data[$i]->id."</td>".
	        "<td>".$data[$i]->name."</td>".
			"</tr>";
	    }
	} else
	{
		$htmlString .= "<tr>".
	        "<td colspan=\"4\">No data found.</td>".
	        "</tr>";
	}
	return $htmlString;
}

?>