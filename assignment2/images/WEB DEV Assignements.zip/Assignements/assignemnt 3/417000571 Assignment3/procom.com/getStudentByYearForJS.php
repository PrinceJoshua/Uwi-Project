<?php

if(isset($_GET['year']))
{
	include 'viewStudents.php';
	$jsonData = getStudents($_GET['year']);
	echo viewStudents($jsonData);
}

?>