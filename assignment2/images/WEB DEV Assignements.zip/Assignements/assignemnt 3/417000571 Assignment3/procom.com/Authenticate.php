<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

class Authenticate
{
	// procom_users.csv
	function loginUser($data)
	{

		if(!is_array($data))
		{
			// Chaaa, no array found 😔
			return false;
		}

		include_once 'Database.php';
		$lilDatabase = new Database();
		$conn = $lilDatabase->getDbConnection();
		
		$email = $data[0];
		$password = $data[1];	

		$stmt = $conn->prepare("SELECT id, fname, lname, status FROM procom_users WHERE email=?");
		$stmt->bind_param("s", $email);
		$stmt->execute();

		$rc = $stmt->bind_result($rid, $rfname, $rlname, $rstatus);

		if($stmt->fetch())
		{
			$session_user = array("em"=>$data[0], 
			"userid"=>$rid,
			 "fname"=>$rfname,
			  "lname"=>$rlname,
			   "role"=>$rstatus,
			    "time"=>date('d/m/Y h:m:s'), // $data2[5] 
			     "pass"=>$data[1]); 
			$session_user = json_encode($session_user);
			$_SESSION["session_user"] = $session_user;
			//var_dump($session_user);
			$lilDatabase->closeDbConnection();
			
			header("Location: console.php");
		} else
		{
			// database either failed to connect or did not find email
			$lilDatabase->closeDbConnection();
			return false;
		}

		$stmt->close();
		$conn->close();
		return false;
	/*
		//fgetcsv
		$row = 1;
		if (($handle = fopen("procom_users.csv", "r")) !== FALSE) 
		{
			while (($data2 = fgetcsv($handle, 1000, ",")) !== FALSE) 
			{
				//$num = count($data2);
				
				if($data[0] == $data2[0])
				{
					// found email
					$session_user = array("em"=>$data[0], 
					"userid"=>$data2[1],
					 "fname"=>$data2[2],
					  "lname"=>$data2[3],
					   "role"=>$data2[4],
					    "time"=>date('d/m/Y h:m:s'), // $data2[5] 
					     "pass"=>$data2[5]); 
					$session_user = json_encode($session_user);
					$_SESSION["session_user"] = $session_user;
					var_dump($session_user);
					header("Location: console.php");

					//var_dump($_SERVER['HTTP_REFERER']);
					die();

				}
			}
			// not found/valid
			fclose($handle);
		}
	*/	
		// create array that goes in session
	}

	function isUserLoggedIn()
	{
		return isset($_SESSION['session_user']);
	}


	function getUserInfo(string $field)
	{
		if($this->isUserLoggedIn())
		{
			// user is log in
			if($field == "em" ||
			 $field == "userid" ||
			  $field == "fname" ||
			   $field == "lname" ||
			    $field == "role" ||
			     $field == "time" ||
			      $field == "pass")
			{
				$session_user = $_SESSION["session_user"];
				//var_dump($session_user);
				$session_user = json_decode($session_user, true);
				//var_dump($session_user);
				//var_dump($field);
				$stringResult = $session_user[$field];
				//var_dump($session_user);
				return $stringResult;
			}
		}	

		return $field.": nothing found ";// notthing found
	}

	function logOutUser()
	{
		session_destroy();
		header("Location: index.php");
		die();
	}
}
?>