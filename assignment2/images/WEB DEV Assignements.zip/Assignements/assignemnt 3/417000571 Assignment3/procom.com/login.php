<?php
if(!isset($_SESSION)) 
{ 
    session_start(); 
} 

//  intialise error msg
$GLOBALS['err_msg'] = "";


// redirect if post does not exist
if(isset($_POST['isJSGood']) || isset($_POST['email']) || isset($_POST['password']))
{
	// get POST data
	$jstatus = $_POST['isJSGood'];
	$email = $_POST['email'];
	$password = $_POST['password'];

	//
	$infoData = array($email,$password);

	include 'validate.php';
	$lilValidate = new Validate();

	// no javascript then do validation before verfication of credentials
	if(!$jstatus)
	{
		/// todo: need to handlle all situatuions login, add new student, update INFACT I MIGHT BE ABL TO REMOVE
		$status2 = $lilValidate->isEmailValid($infoData[0]);
		$status3 = $lilValidate->isPasswordValid($infoData[1]);

		// if any data was bad send them home
		if (!$status2 || !$status3)
		{
			// sent home with error msg
			$_SESSION["errormsg"]=$GLOBALS['err_msg'];
			header("Location: index.php");
			die();
		}
	}

	// validation has at least been done by javascript or php 
	$credentialStatus = $lilValidate->areCredentialsValid($infoData);

	if($credentialStatus)
	{
		include 'Authenticate.php';
		$lilAuthenticate = new Authenticate();
		$lilAuthenticate->loginUser($infoData);
	} else 
	{
		$_SESSION["errormsg"]=$GLOBALS['err_msg'].=" Wrong Email or Password entered";
		header("Location: index.php");
		die();
	}
	
	
}






?>