//var javaG = document.getElementById("javascriptgood").value ;
//var javaG = document.getElementById('javascriptgood').value = '1';
document.getElementById("isJSGood").value = "1";
document.getElementById("login-button").setAttribute("type","button");
//javaG.value = new Number(1);