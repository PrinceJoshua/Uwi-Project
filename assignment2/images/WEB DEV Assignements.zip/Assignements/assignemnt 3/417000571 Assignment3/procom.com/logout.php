<?php
include_once 'Authenticate.php';
$lilAuthenticate = new Authenticate();
$lilAuthenticate->logOutUser();
?>