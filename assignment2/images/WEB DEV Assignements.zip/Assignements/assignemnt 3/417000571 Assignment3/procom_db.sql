-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2019 at 01:08 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `procom_db`
--
CREATE DATABASE IF NOT EXISTS `procom_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `procom_db`;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `name`) VALUES
('COMP2210', 'Mathematics for Computer Science II'),
('COMP2220', 'Computer System Architecture'),
('COMP2225', 'Software Engineering'),
('COMP2232', 'Object-Oriented Programming Concepts'),
('COMP2235', 'Networks I'),
('COMP2245', 'Web Development Concepts, Tools & Practices'),
('COMP2410', 'Computing in the Digital Age'),
('COMP2415', 'Information Technology Engineering'),
('COMP2611', 'Data Structures');

-- --------------------------------------------------------

--
-- Table structure for table `procom_users`
--

CREATE TABLE `procom_users` (
  `email` varchar(345) NOT NULL,
  `id` int(9) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `passw` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `procom_users`
--

INSERT INTO `procom_users` (`email`, `id`, `fname`, `lname`, `status`, `date_time`, `passw`) VALUES
('john.doe@uwistaff.com', 417000123, 'John', 'Doe', 'Administator', '2019-04-01 06:22:24', '123isthepassworD'),
('test.man@test.com', 400000000, 'Test', 'Man', 'Normal', '2019-04-01 00:00:00', 'password1234');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(9) NOT NULL,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `email` varchar(345) NOT NULL,
  `address` varchar(255) NOT NULL,
  `year` smallint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `fname`, `lname`, `email`, `address`, `year`) VALUES
(417000572, 'Dre', 'Hyland', 'dre.hyland@mycavehill.com', 'black rock main road st michael', 2017),
(417000571, 'Andre', 'Hyland', 'andre.hyland@mycavehill.uwi.edu', 'black rock', 2018),
(462198301, 'Updated', 'Man2', 'test@test.com', 'jsdhkaidhkasda', 2016),
(450473537, 'seth', 'mcfarlane', '2017guy.mcfarlane@uwistaff.com', 'sadasdasdasdasdasdasd', 2017),
(483585102, 'John', 'Doe', 'john.doe@uwistaff.com', 'dasdasdasdasdasd', 2016),
(473287749, 'Ignored', 'Guy', 'asdas@notreal.com', 'dasdasdasdasdasd', 2018),
(466609335, 'Updated', 'Guy1', 'dsadas@sadas.das', 'Some place nice', 2018),
(417896321, 'fdklmfdskn', 'kldsfklds', 'dkfdsklfs@dfjksjk.djfsdk', 'klfmsdkl', 2016),
(423420751, 'Mary', 'Brown', 'mary.brown@notreal.com', 'somewhere on mars', 2018),
(418693855, 'John', 'Cena', 'john.cena@uwistaff.com', 'dfsdfds', 2018),
(437596809, 'Renee', 'Hyland', 'reneehyland@hotmail.com', 'number 7 belfield black rock st michael', 2018);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `procom_users`
--
ALTER TABLE `procom_users`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
