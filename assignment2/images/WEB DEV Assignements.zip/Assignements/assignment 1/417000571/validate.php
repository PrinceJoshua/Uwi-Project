<?php
session_start();

if($_POST['javascriptgood'])	
{
	echo "dont do ****";
}
else
{
	echo "do some ****";
}

?>