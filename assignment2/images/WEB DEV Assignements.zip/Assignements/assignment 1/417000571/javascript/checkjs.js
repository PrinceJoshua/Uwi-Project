var test = document.getElementById("javascriptgood");
test.value =1;