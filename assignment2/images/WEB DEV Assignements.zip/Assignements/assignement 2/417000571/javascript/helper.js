// stuff to help my website

function menuClick()
{
	var menubtn = document.getElementById("forToggle");
	if (menubtn.style.display === "none") 
	{
		menubtn.style.display = "block";
	}
	else 
	{
		menubtn.style.display = "none";
	}
	
}
/*
var menubtn = document.getElementById("ham-icon");
menubtn.onclick = */ 

function logOut()
{
	console.log("logged out");
	sessionStorage.clear();
	window.stop();
	window.location.replace("index.html");
	
}
if(document.getElementById("stdnt-table"))
{
	document.onload = loadData();
	
	// student page stuff
	// get menu container
	var menu = document.getElementById("stdnt_menu"); 
	// get all menu items
	var tabs = menu.getElementsByClassName("stdnt_menu_item"); 
	
	for (var i = 0; i < tabs.length; i++) {
  	tabs[i].addEventListener("mouseup", function() {
		var current = document.getElementsByClassName("stdnt_menu_active");
		current[0].className = current[0].className.replace(" stdnt_menu_active", "");
		this.className += " stdnt_menu_active";
		console.log("we hay"+current[0].getAttribute("href").substr(1));
			window.location.hash = current[0].getAttribute("href").substr(1);
			loadData(); // calls data based on fragment in url ex. 2016, 2017, 2018
		});
	}
}
function loadData() 
{
	// validate year
	var year = window.location.hash;
	year = year.substr(1);
	year=parseInt(year);
	console.log(year);
	
	if(isNaN(year))
	{
		// just load 2018
		year = 2018;
		console.log("default");
	}
	// user logged 
	if(true)//localStorage.getItem("student_table_data") === null)
	{
		
	}
	loadStudents(year);
	
	
}



function loadStudents(year)
{
	if(localStorage.getItem("student_table_data") === null)
	{
		var table = document.getElementById("stdnt-table");
		table.innerHTML = "";
		console.log("welp no student data found");
		tr = document.createElement('tr');
		td1 = document.createElement('td');
		td1.innerHTML = "No data found for year <b>\["+year+"]</b>";
		tr.appendChild(td1);
		table.appendChild(tr);
		return;
	} else
	{
		var table = document.getElementById("stdnt-table");
		table.innerHTML = "";
		var tr;
		var td1;
		var td2;
		var td3;
		var td4;
		var td5;
		var td6;
		var td7;
		var retrievedJsonData = JSON.parse(localStorage.getItem("student_table_data"));
		
		if(doesRecordExist(retrievedJsonData,year))
		{
		
			retrievedJsonData.forEach(function(row){
				//console.log(row['year']);
				if(row['year'] == year)
				{
					tr = document.createElement('tr');
					td1 = document.createElement('td');
					td2 = document.createElement('td');
					td3 = document.createElement('td');
					td4 = document.createElement('td');
					td5 = document.createElement('td');
					td6 = document.createElement('td');
					td7 = document.createElement('td');

					td1.innerHTML = "<button class='stdnt_btn blue' onclick='updateStudent("+row['id']+")'>Edit</button>";
					td2.innerHTML = "<button class='stdnt_btn red' onclick='deleteStudent("+row['id']+")'>Delete</button>";
					td3.innerHTML = row['id'];
					td4.innerHTML = row['fname'];
					td5.innerHTML = row['lname'];
					td6.innerHTML = row['email'];
					td7.innerHTML = row['address'];
					tr.appendChild(td1);
					tr.appendChild(td2);
					tr.appendChild(td3);
					tr.appendChild(td4);
					tr.appendChild(td5);
					tr.appendChild(td6);
					tr.appendChild(td7);

					table.appendChild(tr);
					//console.log("sjd");
				}
			});
		} else
			{
				tr = document.createElement('tr');
				td1 = document.createElement('td');
				td1.innerHTML = "No data found for year <b>\["+year+"]</b>";
				tr.appendChild(td1);
				table.appendChild(tr);
			}
	}
	function doesRecordExist(array,year)
	{
		return array.some(function(element) {
			return parseInt(element.year) === year;
		}); 
	}
	
	
}

//window.onload = myFunction(2018);